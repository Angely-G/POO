/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
public class Persona {
    public String Nombre;
    public String Identidad;

    public Persona(String Nombre, String Identidad) {
        this.Nombre = Nombre;
        this.Identidad = Identidad;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getIdentidad() {
        return Identidad;
    }

    public void setIdentidad(String Identidad) {
        this.Identidad = Identidad;
    }
    
    public static void main(String[] args) {
        Seccion seccion = new Seccion("ABC123");
        seccion.mostrarPantalla();
    }
    
}
