/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
public class ProfesorIS extends Persona{
    public String Area;
    public String NumeroEmpleado;

    public String getNumeroEmpleado() {
        return NumeroEmpleado;
    }

    public void setNumeroEmpleado(String NumeroEmpleado) {
        this.NumeroEmpleado = NumeroEmpleado;
    }

    

    public String getArea() {
        return Area;
    }

    public void setArea(String Area) {
        this.Area = Area;
    }

    public ProfesorIS(String NumeroEmpleado, String Area, String Nombre, String Identidad) {
        super(Nombre, Identidad);
        this.Area = Area;
        this.NumeroEmpleado = NumeroEmpleado;
    }
    public void mandarNumeroEmpleado(){
       System.out.println("\nEl numero de Empleado del Docente: "+NumeroEmpleado);
    }
}
