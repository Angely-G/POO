/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
public class Seccion {
    public String SeccionID;

    public Seccion(String SeccionID) {
        this.SeccionID = SeccionID;
    }
    
    
    public String getSeccionID() {
        return SeccionID;
    }

    public void setSeccionID(String SeccionID) {
        this.SeccionID = SeccionID;
    }
    public void mostrarPantalla(){
        Clase cl = new Clase("IS410");
        ProfesorIS profe = new ProfesorIS("#ABC123","","","");
        cl.mandarCodigo();
        profe.mandarNumeroEmpleado();
        //System.out.println("\nEl numero de Empleado del Docente: ");
        System.out.println("\nFormato de Clase: A1000");
    }
}
