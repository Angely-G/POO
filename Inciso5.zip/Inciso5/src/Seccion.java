/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
public class Seccion implements Matricula{
    public String SeccionID;

    public Seccion(String SeccioID) {
        this.SeccionID = SeccionID;
    }

    public String getSeccionID() {
        return SeccionID;
    }

    public void setSeccionID(String SeccionID) {
        this.SeccionID = SeccionID;
    }
    
    public void DatosAlumno(){
        Alumno alu = new Alumno("121323"); 
        alu.Registro();
        System.out.println("-->IDENTIFICADOR DE SECCION: "+SeccionID);
        
    }

    @Override
    public void AgregarAlumno() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void CancelarAlumno() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
