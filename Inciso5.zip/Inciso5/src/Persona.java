
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
public class Persona {
    public String Nombre;

    /**
     *
     * @param Nombre the value of Nombre
     */
    public Persona(String Nombre) {
        this.Nombre = Nombre;
    }

    private Persona() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
   // ArrayList<String>estudiantes;
    
    public static void main(String[] args) {
     //   Persona per = new Persona();
       // per.estudiantes = new ArrayList();
        System.out.println("Agregar Alumno con los siguientes datos: ");
       Seccion seccion = new Seccion("");
       seccion.DatosAlumno();
        
    }
    
   /* public void leerOpcion(){
        Scanner teclado = new Scanner(System.in);
        int opcion = 0;
        do{
            System.out.println("Lista de Alumnos");
            System.out.println("1. Agregar");
            System.out.println("2.Eliminar");
            System.out.println("3. Salir");
            opcion = teclado.nextInt();
            switch (opcion){
                case 1:
                  insertarValor();  
                  break;
                case 2:
                    eliminarValor();
                case 3:
                    
     */       }
        
     