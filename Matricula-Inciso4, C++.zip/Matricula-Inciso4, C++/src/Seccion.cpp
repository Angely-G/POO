#include "Seccion.h"
#include "Clase.h"
#include "ProfesorIS.h"

Seccion::Seccion(const std::wstring &SeccionID)
{
	this->SeccionID = SeccionID;
}

std::wstring Seccion::getSeccionID()
{
	return SeccionID;
}

void Seccion::setSeccionID(const std::wstring &SeccionID)
{
	this->SeccionID = SeccionID;
}

void Seccion::mostrarPantalla()
{
	Clase *cl = new Clase(L"IS410");
	ProfesorIS *profe = new ProfesorIS(L"#ABC123",L"",L"",L"");
	cl->mandarCodigo();
	profe->mandarNumeroEmpleado();
	std::wcout << L"\nFormato de Clase: A1000" << std::endl;

	delete profe;
	delete cl;
}
