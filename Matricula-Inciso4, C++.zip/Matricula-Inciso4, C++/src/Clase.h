#pragma once

#include <string>
#include <iostream>

class Clase
{
public:
	std::wstring Codigo;

	Clase(const std::wstring &Codigo);

	virtual std::wstring getCodigo();

	virtual void setCodigo(const std::wstring &Codigo);

	virtual void mandarCodigo();

};
