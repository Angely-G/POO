#include "Persona.h"
#include "Seccion.h"

Persona::Persona(const std::wstring &Nombre, const std::wstring &Identidad)
{
	this->Nombre = Nombre;
	this->Identidad = Identidad;
}

std::wstring Persona::getNombre()
{
	return Nombre;
}

void Persona::setNombre(const std::wstring &Nombre)
{
	this->Nombre = Nombre;
}

std::wstring Persona::getIdentidad()
{
	return Identidad;
}

void Persona::setIdentidad(const std::wstring &Identidad)
{
	this->Identidad = Identidad;
}

void Persona::main(std::vector<std::wstring> &args)
{
	Seccion *seccion = new Seccion(L"ABC123");
	seccion->mostrarPantalla();

	delete seccion;
}
