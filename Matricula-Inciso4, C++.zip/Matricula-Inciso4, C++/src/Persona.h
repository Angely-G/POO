#pragma once

#include <string>
#include <vector>

class Persona
{
public:
	std::wstring Nombre;
	std::wstring Identidad;

	Persona(const std::wstring &Nombre, const std::wstring &Identidad);

	virtual std::wstring getNombre();

	virtual void setNombre(const std::wstring &Nombre);

	virtual std::wstring getIdentidad();

	virtual void setIdentidad(const std::wstring &Identidad);

	static void main(std::vector<std::wstring> &args);

};
