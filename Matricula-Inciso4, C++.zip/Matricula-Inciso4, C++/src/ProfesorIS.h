#pragma once

#include "Persona.h"
#include <string>
#include <iostream>

class ProfesorIS : public Persona
{
public:
	std::wstring Area;
	std::wstring NumeroEmpleado;

	virtual std::wstring getNumeroEmpleado();

	virtual void setNumeroEmpleado(const std::wstring &NumeroEmpleado);



	virtual std::wstring getArea();

	virtual void setArea(const std::wstring &Area);

	ProfesorIS(const std::wstring &NumeroEmpleado, const std::wstring &Area, const std::wstring &Nombre, const std::wstring &Identidad);
	virtual void mandarNumeroEmpleado();
};
