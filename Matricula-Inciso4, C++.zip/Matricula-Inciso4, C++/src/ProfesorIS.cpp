#include "ProfesorIS.h"

std::wstring ProfesorIS::getNumeroEmpleado()
{
	return NumeroEmpleado;
}

void ProfesorIS::setNumeroEmpleado(const std::wstring &NumeroEmpleado)
{
	this->NumeroEmpleado = NumeroEmpleado;
}

std::wstring ProfesorIS::getArea()
{
	return Area;
}

void ProfesorIS::setArea(const std::wstring &Area)
{
	this->Area = Area;
}

ProfesorIS::ProfesorIS(const std::wstring &NumeroEmpleado, const std::wstring &Area, const std::wstring &Nombre, const std::wstring &Identidad) : Persona(Nombre, Identidad)
{
	this->Area = Area;
	this->NumeroEmpleado = NumeroEmpleado;
}

void ProfesorIS::mandarNumeroEmpleado()
{
   std::wcout << L"\nEl numero de Empleado del Docente: " << NumeroEmpleado << std::endl;
}
