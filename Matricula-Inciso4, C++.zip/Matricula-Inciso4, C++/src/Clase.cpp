#include "Clase.h"

Clase::Clase(const std::wstring &Codigo)
{
	this->Codigo = Codigo;
}

std::wstring Clase::getCodigo()
{
	return Codigo;
}

void Clase::setCodigo(const std::wstring &Codigo)
{
	this->Codigo = Codigo;
}

void Clase::mandarCodigo()
{
	std::wcout << L"Codigo Clase: " << Codigo << std::endl;

}
