#include "Alumno.h"

Alumno::Alumno(const std::wstring &NumeroRegistro, const std::wstring &Nombre, const std::wstring &Identidad) : Persona(Nombre, Identidad)
{
	this->NumeroRegistro = NumeroRegistro;
}

std::wstring Alumno::getNumeroRegistro()
{
	return NumeroRegistro;
}

void Alumno::setNumeroRegistro(const std::wstring &NumeroRegistro)
{
	this->NumeroRegistro = NumeroRegistro;
}
