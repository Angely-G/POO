#pragma once

#include "Persona.h"
#include <string>

class Alumno : public Persona
{
public:
	std::wstring NumeroRegistro;

	Alumno(const std::wstring &NumeroRegistro, const std::wstring &Nombre, const std::wstring &Identidad);

	virtual std::wstring getNumeroRegistro();

	virtual void setNumeroRegistro(const std::wstring &NumeroRegistro);


};
