#pragma once

#include <string>
#include <iostream>

class Seccion
{
public:
	std::wstring SeccionID;

	Seccion(const std::wstring &SeccionID);


	virtual std::wstring getSeccionID();

	virtual void setSeccionID(const std::wstring &SeccionID);
	virtual void mostrarPantalla();
};
