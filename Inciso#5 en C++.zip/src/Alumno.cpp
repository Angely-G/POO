#include "Alumno.h"

Alumno::Alumno(const std::wstring &Nombre) : Persona(Nombre)
{
	this->NumeroRegistro = NumeroRegistro;
}

std::wstring Alumno::getNumeroRegistro()
{
	return NumeroRegistro;
}

void Alumno::setNumeroRegistro(const std::wstring &NumeroRegistro)
{
	this->NumeroRegistro = NumeroRegistro;
}

void Alumno::Registro()
{
	std::wcout << L" --> REGISTRO: " << NumeroRegistro << std::endl;
}
