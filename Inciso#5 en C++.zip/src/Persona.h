#pragma once

#include <string>
#include <vector>
#include <iostream>
#include "exceptionhelper.h"

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
class Persona
{
public:
	std::wstring Nombre;

	/**
	 *
	 * @param Nombre the value of Nombre
	 */
	Persona(const std::wstring &Nombre);

private:
	Persona();

public:
	virtual std::wstring getNombre();

	virtual void setNombre(const std::wstring &Nombre);

   // ArrayList<String>estudiantes;

	static void main(std::vector<std::wstring> &args);

   /* public void leerOpcion(){
        Scanner teclado = new Scanner(System.in);
        int opcion = 0;
        do{
            System.out.println("Lista de Alumnos");
            System.out.println("1. Agregar");
            System.out.println("2.Eliminar");
            System.out.println("3. Salir");
            opcion = teclado.nextInt();
            switch (opcion){
                case 1:
                  insertarValor();  
                  break;
                case 2:
                    eliminarValor();
                case 3:
                    
     */
};

