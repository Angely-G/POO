#include "Persona.h"
#include "Seccion.h"

Persona::Persona(const std::wstring &Nombre)
{
	this->Nombre = Nombre;
}

Persona::Persona()
{
	throw UnsupportedOperationException(L"Not supported yet."); //To change body of generated methods, choose Tools | Templates.
}

std::wstring Persona::getNombre()
{
	return Nombre;
}

void Persona::setNombre(const std::wstring &Nombre)
{
	this->Nombre = Nombre;
}

void Persona::main(std::vector<std::wstring> &args)
{
 //   Persona per = new Persona();
   // per.estudiantes = new ArrayList();
	std::wcout << L"Agregar Alumno con los siguientes datos: " << std::endl;
   Seccion *seccion = new Seccion(L"");
   seccion->DatosAlumno();

	delete seccion;
}
