#include "Seccion.h"
#include "Alumno.h"

Seccion::Seccion(const std::wstring &SeccioID)
{
	this->SeccionID = SeccionID;
}

std::wstring Seccion::getSeccionID()
{
	return SeccionID;
}

void Seccion::setSeccionID(const std::wstring &SeccionID)
{
	this->SeccionID = SeccionID;
}

void Seccion::DatosAlumno()
{
	Alumno *alu = new Alumno(L"121323");
	alu->Registro();
	std::wcout << L"-->IDENTIFICADOR DE SECCION: " << SeccionID << std::endl;

	delete alu;
}

void Seccion::AgregarAlumno()
{
	throw UnsupportedOperationException(L"Not supported yet."); //To change body of generated methods, choose Tools | Templates.
}

void Seccion::CancelarAlumno()
{
	throw UnsupportedOperationException(L"Not supported yet."); //To change body of generated methods, choose Tools | Templates.
}
