#pragma once

#include "Matricula.h"
#include <string>
#include <iostream>
#include "exceptionhelper.h"

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
class Seccion : public Matricula
{
public:
	std::wstring SeccionID;

	Seccion(const std::wstring &SeccioID);

	virtual std::wstring getSeccionID();

	virtual void setSeccionID(const std::wstring &SeccionID);

	virtual void DatosAlumno();

	void AgregarAlumno() override;

	void CancelarAlumno() override;

};
