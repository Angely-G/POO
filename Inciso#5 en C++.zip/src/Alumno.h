#pragma once

#include "Persona.h"
#include <string>
#include <iostream>

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
class Alumno : public Persona
{
public:
	std::wstring NumeroRegistro;

	Alumno(const std::wstring &Nombre);

	virtual std::wstring getNumeroRegistro();

	virtual void setNumeroRegistro(const std::wstring &NumeroRegistro);

	virtual void Registro();
};
